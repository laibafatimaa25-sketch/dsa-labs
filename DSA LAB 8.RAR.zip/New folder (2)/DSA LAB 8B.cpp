#include <iostream>
#include <queue>
#include <stack>
#include <string>
using namespace std;

class GarageSystem {
    queue<int> road;
    stack<int> garage;
public:
    void On_road(int id) {
        road.push(id);
        cout << "Truck " << id << " is now on the road.\n";
    }
    void Enter_garage(int id) {
        if (!road.empty() && road.front() == id) {
            garage.push(id);
            road.pop();
            cout << "Truck " << id << " entered the garage.\n";
        } else {
            cout << "Truck " << id << " is not at the front of the road queue.\n";
        }
    }
    void Exit_garage(int id) {
        if (garage.empty()) {
            cout << "Garage is empty.\n";
            return;
        }
        if (garage.top() == id) {
            cout << "Truck " << id << " exited the garage.\n";
            garage.pop();
        } else {
            cout << "Truck " << id << " is not near garage door.\n";
        }
    }
    void Show_trucks(string location) {
        if (location == "road") {
            if (road.empty()) {
                cout << "No trucks on the road.\n";
                return;
            }
            queue<int> temp = road;
            cout << "Trucks on the road: ";
            while (!temp.empty()) {
                cout << temp.front() << " ";
                temp.pop();
            }
            cout << endl;
        } else if (location == "garage") {
            if (garage.empty()) {
                cout << "No trucks in the garage.\n";
                return;
            }
            stack<int> temp = garage;
            cout << "Trucks in the garage (top=nearest door): ";
            while (!temp.empty()) {
                cout << temp.top() << " ";
                temp.pop();
            }
            cout << endl;
        } else {
            cout << "Invalid location.\n";
        }
    }
};

int main() {
    GarageSystem g;
    int choice, id;
    string loc;
    do {
        cout << "\n1. On_road\n2. Enter_garage\n3. Exit_garage\n4. Show_trucks\n5. Exit\nEnter choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter truck id: ";
            cin >> id;
            g.On_road(id);
            break;
        case 2:
            cout << "Enter truck id to enter garage: ";
            cin >> id;
            g.Enter_garage(id);
            break;
        case 3:
            cout << "Enter truck id to exit garage: ";
            cin >> id;
            g.Exit_garage(id);
            break;
        case 4:
            cout << "Enter location (road/garage): ";
            cin >> loc;
            g.Show_trucks(loc);
            break;
        case 5:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice.\n";
        }
    } while (choice != 5);
    
    return 0 ;