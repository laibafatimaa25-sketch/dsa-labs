#include <iostream>
#include <string>
using namespace std;

class Applicant {
public:
    int applicant_id;
    float height;
    float weight;
    float eyesight;
    string status;
    Applicant() {
        applicant_id = 0;
        height = 0;
        weight = 0;
        eyesight = 0;
        status = "Waiting";
    }
};

class Node {
public:
    Applicant data;
    Node* next;
    Node* prev;
    Node(Applicant a) {
        data = a;
        next = nullptr;
        prev = nullptr;
    }
};

class Queue {
    Node* front;
    Node* rear;
public:
    Queue() {
        front = nullptr;
        rear = nullptr;
    }
    void enqueue(Applicant a) {
        Node* newNode = new Node(a);
        if (!rear) {
            front = rear = newNode;
            return;
        }
        rear->next = newNode;
        newNode->prev = rear;
        rear = newNode;
    }
    void dequeue() {
        if (!front) {
            cout << "No applicants in queue.\n";
            return;
        }
        Node* temp = front;
        front = front->next;
        if (front)
            front->prev = nullptr;
        else
            rear = nullptr;
        cout << "Applicant ID " << temp->data.applicant_id << " has given the test and left the queue.\n";
        delete temp;
    }
    void removeSecond() {
        if (!front || !front->next) {
            cout << "No second applicant to remove.\n";
            return;
        }
        Node* second = front->next;
        front->next = second->next;
        if (second->next)
            second->next->prev = front;
        else
            rear = front;
        cout << "Applicant ID " << second->data.applicant_id << " (2nd position) left the queue due to urgency.\n";
        delete second;
    }
    void display() {
        if (!front) {
            cout << "Queue is empty.\n";
            return;
        }
        Node* temp = front;
        cout << "\nCurrent Queue:\n";
        while (temp) {
            cout << "Applicant ID: " << temp->data.applicant_id
                 << ", Height: " << temp->data.height
                 << ", Weight: " << temp->data.weight
                 << ", Eyesight: " << temp->data.eyesight
                 << ", Status: " << temp->data.status << endl;
            temp = temp->next;
        }
    }
};

int main() {
    Queue q;
    for (int i = 1; i <= 7; i++) {
        Applicant a;
        a.applicant_id = i;
        a.height = 160 + i;
        a.weight = 55 + i;
        a.eyesight = 6.0;
        q.enqueue(a);
    }

    q.display();

    cout << "\nRemoving 2nd applicant due to urgency...\n";
    q.removeSecond();
    q.display();

    cout << "\nFirst applicant gives the test...\n";
    q.dequeue();
    q.display();

    Applicant newApplicant;
    newApplicant.applicant_id = 8;
    newApplicant.height = 172;
    newApplicant.weight = 65