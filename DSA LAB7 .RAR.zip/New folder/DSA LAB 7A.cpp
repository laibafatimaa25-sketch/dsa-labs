#include <iostream>
#include <string>
using namespace std;

class Node {
public:
    string title;
    float price;
    int edition;
    int pages;
    Node* next;
    Node(string t, float p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
        next = nullptr;
    }
};

class Stack {
    Node* top;
public:
    Stack() { top = nullptr; }
    void push(string t, float p, int e, int pg) {
        Node* newNode = new Node(t, p, e, pg);
        newNode->next = top;
        top = newNode;
    }
    void pop() {
        if (!top) return;
        Node* temp = top;
        top = top->next;
        delete temp;
    }
    void peek() {
        if (!top) return;
        cout << "Top Book:\n";
        cout << "Title: " << top->title << ", Price: " << top->price << ", Edition: " << top->edition << ", Pages: " << top->pages << endl;
    }
    void display() {
        Node* temp = top;
        cout << "Books in Stack:\n";
        while (temp) {
            cout << "Title: " << temp->title << ", Price: " << temp->price << ", Edition: " << temp->edition << ", Pages: " << temp->pages << endl;
            temp = temp->next;
        }
    }
};

int main() {
    Stack s;
    s.push("Book1", 250.5, 1, 300);
    s.push("Book2", 350.75, 2, 400);
    s.push("Book3", 199.99, 1, 250);
    s.push("Book4", 450.25, 3, 500);
    s.push("Book5", 299.49, 2, 320);
    s.peek();
    s.pop();
    s.pop();
    s.display();
    return 0;
}




