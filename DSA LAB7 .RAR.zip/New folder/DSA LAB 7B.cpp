#include <iostream>
using namespace std;

class Inventory {
    int serialNum;
    int manufactYear;
    int lotNum;
public:
    Inventory() { serialNum = 0; manufactYear = 0; lotNum = 0; }
    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }
    void display() {
        cout << "Serial Number: " << serialNum << ", Year: " << manufactYear << ", Lot Number: " << lotNum << endl;
    }
};

class Node {
public:
    Inventory item;
    Node* next;
    Node(Inventory i) {
        item = i;
        next = nullptr;
    }
};

class Stack {
    Node* top;
public:
    Stack() { top = nullptr; }
    void push(Inventory i) {
        Node* newNode = new Node(i);
        newNode->next = top;
        top = newNode;
    }
    bool pop(Inventory &i) {
        if (!top) return false;
        Node* temp = top;
        i = top->item;
        top = top->next;
        delete temp;
        return true;
    }
    void displayAll() {
        Node* temp = top;
        if (!temp) {
            cout << "No parts remaining in inventory.\n";
            return;
        }
        cout << "Remaining parts in inventory:\n";
        while (temp) {
            temp->item.display();
            temp = temp->next;
        }
    }
};

int main() {
    Stack s;
    int choice;
    do {
        cout << "\n1. Add part to inventory\n2. Take part from inventory\n3. Exit\nEnter choice: ";
        cin >> choice;
        if (choice == 1) {
            int serial, year, lot;
            cout << "Enter Serial Number: ";
            cin >> serial;
            cout << "Enter Manufacturing Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;
            Inventory part;
            part.setData(serial, year, lot);
            s.push(part);
            cout << "Part added to inventory.\n";
        } else if (choice == 2) {
            Inventory removed;
            if (s.pop(removed)) {
                cout << "Part removed from inventory:\n";
                removed.display();
            } else {
                cout << "Inventory is empty.\n";
            }
        }
    } while (choice != 3);
    s.displayAll();
    return 0;
}